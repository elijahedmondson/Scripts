################################################################################
# Get the Sanger SNPs and condense them down to unique strain distribution
# patterns at each location.
# This will write out a tab delimited file with the chr, position and SDP
# code. The code will be binary with the founders listed in alphabetical
# order, i.e. A-H. A '1' indicates that the strain contains an alternate allele
# and '0' indicates the reference. The binary code run from right to left.
# i.e. '19' is 00010011.
################################################################################
### NOTE: we consider heterozygotes and trimorphic SNPs as bimorphic. ##########
################################################################################
# Daniel Gatti
# Dan.Gatti@jax.org
# Dec. 6, 2014
################################################################################
# Create a function to generate the file, given the array and SNP file.
condense.sanger.snps = function(markers, snp.file, strains, out.file) {

  # Write out header information to the output file.
  outf = file(description = out.file, open = "w")

  # Get the header information.
  tf = TabixFile(snp.file)
  hdr = headerTabix(tf)
  cn = strsplit(hdr$header[length(hdr$header)], split = "\t")[[1]]
  cn = sub("^#", "", cn)

  # Check that the strains are in the file.
  if(!all(strains[strains != "C57BL_6J"] %in% cn)) {
    stop(paste("Some strains are not in the SNP file. Strains in file:",
         paste(cn[-(1:9)], collapse = ",")))
  } # if(!all(strains %in% cn))

  orig.strains = strains
  keep = match(strains, cn)

  # Check for C57BL/6J.
  bl6 = FALSE
  na = which(is.na(keep))
  if(length(na) > 0) {
    if(strains[na] == "C57BL_6J") {
      bl6 = na
      strains = strains[-na]
    } # if(strains[na] == "C57BL_6J")
  } # if(any(is.na(keep)))

  # Get the indices of the allele calls to place them in the loop below.
  m = which(cn[keep] %in% orig.strains)

  # Get the SNPs and each chromosome.
  for(c in 1:length(seqlevels(markers))) {

    print(seqlevels(markers)[c])

    # Get the markers on the current chromosome.
    cur.chr = markers[seqnames(markers) == seqlevels(markers)[c]]
    
    # Get SNPs from the beginning of the chromosome to the first marker.
    gr = GRanges(seqnames = seqnames(cur.chr)[1], ranges = IRanges(start = 0,
                 end = 200e6))

    # Get the SNPs on this chromosome.
    snps = scanTabix(file = snp.file, param = gr)[[1]]
    snps = strsplit(snps, split = "\t")
    calls = matrix(0, nrow = length(snps), ncol = length(orig.strains), 
            dimnames = list(NULL, c(cn[keep[1:(bl6-1)]], "C57BL_6J",
            cn[keep[(bl6+1):length(keep)]])))

    for(s in 1:length(snps)) {

      # Keep the header columns and the founder strains.
      tmp = snps[[s]][keep[!is.na(keep)]]
      snps[[s]] = snps[[s]][1:5]

      # Keep the first three characters of the allele calls.
      tmp = substring(tmp, 1, 3)
      tmp = (tmp != "0/0") * 1
      calls[s,m] = tmp

    } # for(s)

    snps = matrix(unlist(snps), ncol = 5, byrow = TRUE)

    # Keep only polymorphic SNPs.
    rows.keep = which(rowSums(calls[,colnames(calls) == "C57BL_6J"] == calls) < ncol(calls))
    snps  = snps[rows.keep,]
    calls = calls[rows.keep,]

    # Flip the alleles for SDPs that have more ones than zeros.
    wh = which(rowSums(calls) > ncol(calls) / 2)
    calls[wh,] = (calls[wh,]-1)^2

    sdps = tcrossprod(2^(7:0), calls)[1,]
    sdps = paste(snps[,1], snps[,2], sdps, sep = "\t")

    writeLines(sdps, con = outf, sep = "\n")

  } # for(c)

  close(outf)

  bgzip(file = out.file)
  indexTabix(file = paste0(out.file, ".bgz"), seq = 1, start = 2, end = 2)

} # condense.sanger.snps()
