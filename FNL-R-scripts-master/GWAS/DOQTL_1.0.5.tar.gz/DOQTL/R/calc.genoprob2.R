calc.genoprob2 = function(data, founders, markers,
                 cross = c("DO", "CC", "HS", "DOF1", "other"),
                 array = c("GM", "MM", "muga", "other")) {

  if(missing(data)) {
    stop("Required argument \'data\' argument missing.")
  } # if(missing(data))

  cross = match.arg(cross)

  if(missing(markers)) {
    markers = get.markers(array)
  } # if(missing(markers))

  if(missing(founders)) {
    founders = get.founders(cross)
  } # if(missing(founders))

  tmp = synchronize.data(data, founders, markers)
  data = tmp$data
  founders = tmp$data
  markers = tmp$markers
  rm(tmp)
  gc()

  

} # calc.genoprob2()


get.markers = function(array) {

  if(array %in% c("GM", "MM", "muga")) {

  } else {
    stop(paste("Unable to obtain markers for array \\'", array,
         "\\'."))
  } # else

} # get.markers()


