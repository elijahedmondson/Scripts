DOQTL
=====

QTL mapping for Diversity Outbred mice (and other multi-founder advanced intercrosses)
