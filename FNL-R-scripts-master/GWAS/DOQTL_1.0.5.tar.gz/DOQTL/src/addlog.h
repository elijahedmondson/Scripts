#include <float.h> 
#include <math.h>
#include <stdlib.h>
#include <string.h>

double addlog(double x, double y);
